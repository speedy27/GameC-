#include "SFMLGame.h"
#include <iostream>

SFMLGame::SFMLGame()
    : window(sf::VideoMode(800, 600), "Pokemon C++ Battle"),
      currentState(GameState::MAIN_MENU),
      animationTimer(0.0f),
      animationPlaying(false),
      selectedAttack(0),
      selectedPokemonIndex(0) {
    window.setFramerateLimit(60);
    loadResources();

    menuBackground.setSize(sf::Vector2f(800, 600));
    menuBackground.setFillColor(sf::Color(50, 50, 150));

    selectBackground.setSize(sf::Vector2f(800, 600));
    selectBackground.setFillColor(sf::Color(150, 150, 200));

    sf::Text startOption("Commencer un combat", font, 30);
    startOption.setPosition(300, 200);
    startOption.setFillColor(sf::Color::White);

    sf::Text quitOption("Quitter", font, 30);
    quitOption.setPosition(300, 300);
    quitOption.setFillColor(sf::Color::White);

    menuOptions.push_back(startOption);
    menuOptions.push_back(quitOption);

    battleText.setFont(font);
    battleText.setCharacterSize(24);
    battleText.setFillColor(sf::Color::White);
    battleText.setPosition(50, 450);

    resultText.setFont(font);
    resultText.setCharacterSize(36);
    resultText.setFillColor(sf::Color::Yellow);
    resultText.setPosition(200, 250);

    gameLogic.initialize();
}

void SFMLGame::loadResources() {
    if (!font.loadFromFile("resources/fonts/pokemon.ttf")) {
        std::cerr << "Erreur: Impossible de charger la police" << std::endl;
        font.loadFromFile("resources/fonts/arial.ttf");
    }

    auto loadTexture = [&](const std::string& key, const std::string& path) {
        if (!textures[key].loadFromFile(path)) {
            std::cerr << "Erreur de chargement: " << path << std::endl;
        }
    };

    std::vector<std::pair<std::string, std::string>> textureFiles = {
        {"background", "resources/images/battle_bg.png"},
        {"pikachu_back", "resources/images/pikachu_back.png"},
        {"pikachu_front", "resources/images/pikachu_front.png"},
        {"dracaufeu_back", "resources/images/dracaufeu_back.png"},
        {"dracaufeu_front", "resources/images/dracaufeu_front.png"},
        {"florizarre_back", "resources/images/florizarre_back.png"},
        {"florizarre_front", "resources/images/florizarre_front.png"},
        {"tortank_back", "resources/images/tortank_back.png"},
        {"tortank_front", "resources/images/tortank_front.png"},
        {"alakazam_back", "resources/images/alakazam_back.png"},
        {"alakazam_front", "resources/images/alakazam_front.png"},
        {"ronflex_back", "resources/images/ronflex_back.png"},
        {"ronflex_front", "resources/images/ronflex_front.png"},
        {"attack_thunder", "resources/images/thunder.png"},
        {"attack_fire", "resources/images/fire.png"},
        {"attack_water", "resources/images/water.png"},
        {"attack_grass", "resources/images/grass.png"}
    };

    for (const auto& [key, path] : textureFiles) {
        loadTexture(key, path);
    }

    soundBuffers["select"].loadFromFile("resources/sounds/select.wav");
    soundBuffers["attack"].loadFromFile("resources/sounds/attack.wav");
    soundBuffers["hit"].loadFromFile("resources/sounds/hit.wav");
    soundBuffers["victory"].loadFromFile("resources/sounds/victory.wav");
    soundBuffers["defeat"].loadFromFile("resources/sounds/defeat.wav");

    sounds["select"].setBuffer(soundBuffers["select"]);
    sounds["attack"].setBuffer(soundBuffers["attack"]);
    sounds["hit"].setBuffer(soundBuffers["hit"]);
    sounds["victory"].setBuffer(soundBuffers["victory"]);
    sounds["defeat"].setBuffer(soundBuffers["defeat"]);
}

void SFMLGame::run() {
    sf::Clock clock;
    while (window.isOpen()) {
        float deltaTime = clock.restart().asSeconds();
        handleEvents();
        update(deltaTime);
        render();
    }
}

void SFMLGame::handleEvents() {
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed) {
            window.close();
        }
        if (event.type == sf::Event::KeyPressed) {
            switch (currentState) {
                case GameState::MAIN_MENU:
                    handleMainMenu();
                    break;
                case GameState::POKEMON_SELECT:
                    handlePokemonSelect();
                    break;
                case GameState::BATTLE_MENU:
                    handleBattleMenu();
                    break;
                case GameState::BATTLE_RESULT:
                    if (event.key.code == sf::Keyboard::Return || event.key.code == sf::Keyboard::Space) {
                        currentState = GameState::MAIN_MENU;
                        sounds["select"].play();
                    }
                    break;
                default:
                    break;
            }
        }
    }
}

void SFMLGame::update(float deltaTime) {
    if (currentState == GameState::ATTACK_ANIMATION) {
        handleAttackAnimation(deltaTime);
    }
}

void SFMLGame::render() {
    window.clear();

    switch (currentState) {
        case GameState::MAIN_MENU:
            window.draw(menuBackground);
            for (const auto& option : menuOptions) window.draw(option);
            break;

        case GameState::POKEMON_SELECT:
            window.draw(selectBackground);
            for (const auto& option : pokemonOptions) window.draw(option);
            break;

        case GameState::BATTLE:
        case GameState::BATTLE_MENU:
        case GameState::ATTACK_ANIMATION: {
            sf::Sprite backgroundSprite(textures["background"]);
            window.draw(backgroundSprite);

            window.draw(playerPokemonSprite);
            window.draw(opponentPokemonSprite);
            window.draw(playerHealthBar);
            window.draw(opponentHealthBar);
            window.draw(battleText);

            if (currentState == GameState::BATTLE_MENU) {
                for (const auto& option : attackOptions) window.draw(option);
            }
            break;
        }

        case GameState::BATTLE_RESULT:
            window.draw(sf::Sprite(textures["background"]));
            window.draw(playerPokemonSprite);
            window.draw(opponentPokemonSprite);
            window.draw(resultText);
            break;
    }

    window.display();
}

void SFMLGame::handlePokemonSelect() {
    static int selectedOption = 0;

    if (event.key.code == sf::Keyboard::Up) {
        selectedOption = (selectedOption - 1 + pokemonOptions.size()) % pokemonOptions.size();
        sounds["select"].play();
    } else if (event.key.code == sf::Keyboard::Down) {
        selectedOption = (selectedOption + 1) % pokemonOptions.size();
        sounds["select"].play();
    } else if (event.key.code == sf::Keyboard::Return) {
        selectedPokemonIndex = selectedOption;
        selectOption(selectedOption);
        startBattle();
        sounds["select"].play();
    } else if (event.key.code == sf::Keyboard::Escape) {
        currentState = GameState::MAIN_MENU;
        sounds["select"].play();
    }

    for (size_t i = 0; i < pokemonOptions.size(); ++i) {
        pokemonOptions[i].setFillColor(i == selectedOption ? sf::Color::Yellow : sf::Color::White);
    }
}

void SFMLGame::selectOption(int index) {
    gameLogic.selectPlayerPokemon();
}

void SFMLGame::handleMainMenu() {
    static int selectedOption = 0;

    if (event.key.code == sf::Keyboard::Up) {
        selectedOption = (selectedOption - 1 + menuOptions.size()) % menuOptions.size();
        sounds["select"].play();
    } else if (event.key.code == sf::Keyboard::Down) {
        selectedOption = (selectedOption + 1) % menuOptions.size();
        sounds["select"].play();
    } else if (event.key.code == sf::Keyboard::Return) {
        if (selectedOption == 0) {
            currentState = GameState::POKEMON_SELECT;
            pokemonOptions.clear();
            for (size_t i = 0; i < 6; ++i) {
                sf::Text option("", font, 24);
                switch (i) {
                    case 0: option.setString("Pikachu"); break;
                    case 1: option.setString("Dracaufeu"); break;
                    case 2: option.setString("Florizarre"); break;
                    case 3: option.setString("Tortank"); break;
                    case 4: option.setString("Alakazam"); break;
                    case 5: option.setString("Ronflex"); break;
                }
                option.setPosition(300, 150 + i * 50);
                option.setFillColor(i == 0 ? sf::Color::Yellow : sf::Color::White);
                pokemonOptions.push_back(option);
            }
        } else {
            window.close();
        }
        sounds["select"].play();
    }

    for (size_t i = 0; i < menuOptions.size(); ++i) {
        menuOptions[i].setFillColor(i == selectedOption ? sf::Color::Yellow : sf::Color::White);
    }
}

void SFMLGame::handleBattleMenu() {
    static int selectedOption = 0;

    if (event.key.code == sf::Keyboard::Up) {
        selectedOption = (selectedOption - 1 + attackOptions.size()) % attackOptions.size();
        sounds["select"].play();
    } else if (event.key.code == sf::Keyboard::Down) {
        selectedOption = (selectedOption + 1) % attackOptions.size();
        sounds["select"].play();
    } else if (event.key.code == sf::Keyboard::Return) {
        selectedAttack = selectedOption;
        battleText.setString("Vous utilisez " + attackOptions[selectedOption].getString() + "!");
        currentState = GameState::ATTACK_ANIMATION;
        animationTimer = 0.0f;
        animationPlaying = true;
        sounds["attack"].play();
    }

    for (size_t i = 0; i < attackOptions.size(); ++i) {
        attackOptions[i].setFillColor(i == selectedOption ? sf::Color::Yellow : sf::Color::White);
    }
}

void SFMLGame::handleAttackAnimation(float deltaTime) {
    animationTimer += deltaTime;

    if (animationTimer < 1.0f) {
        opponentPokemonSprite.setPosition(500 + std::sin(animationTimer * 30) * 10, 200);
    } else if (animationTimer < 2.0f) {
        if (animationTimer < 1.1f) sounds["hit"].play();
        battleText.setString("L'attaque est efficace!");
        opponentHealthBar.setSize(sf::Vector2f(
            std::max(0.0f, opponentHealthBar.getSize().x - 0.5f),
            opponentHealthBar.getSize().y
        ));
    } else {
        opponentPokemonSprite.setPosition(500, 200);
        if (opponentHealthBar.getSize().x <= 0) {
            currentState = GameState::BATTLE_RESULT;
            resultText.setString("VICTOIRE!");
            sounds["victory"].play();
        } else {
            currentState = GameState::BATTLE_MENU;
            battleText.setString("Que voulez-vous faire?");
        }
    }
}
void SFMLGame::startBattle() {
    // Simule le choix d'un Pokémon adverse
    std::vector<std::string> pokemons = { "pikachu", "dracaufeu", "florizarre", "tortank", "alakazam", "ronflex" };
    std::string opponentPokemonName = pokemons[rand() % pokemons.size()];

    // Pokémon joueur basé sur la sélection actuelle
    std::string playerPokemonName = pokemonOptions[selectedPokemonIndex].getString();
    std::transform(playerPokemonName.begin(), playerPokemonName.end(), playerPokemonName.begin(), ::tolower);

    // Setup des sprites du combat
    playerPokemonSprite.setTexture(textures[playerPokemonName + "_back"]);
    playerPokemonSprite.setPosition(150, 300);
    playerPokemonSprite.setScale(2.0f, 2.0f);

    opponentPokemonSprite.setTexture(textures[opponentPokemonName + "_front"]);
    opponentPokemonSprite.setPosition(500, 200);
    opponentPokemonSprite.setScale(2.0f, 2.0f);

    // Setup des barres de vie
    playerHealthBar.setSize(sf::Vector2f(200, 20));
    playerHealthBar.setFillColor(sf::Color::Green);
    playerHealthBar.setPosition(150, 250);

    opponentHealthBar.setSize(sf::Vector2f(200, 20));
    opponentHealthBar.setFillColor(sf::Color::Green);
    opponentHealthBar.setPosition(500, 150);

    // Setup des attaques
    attackOptions.clear();
    std::vector<std::string> attacks;

    if (playerPokemonName == "pikachu") {
        attacks = { "Eclair", "Vive-Attaque", "Tonnerre", "Fatal-Foudre" };
    } else if (playerPokemonName == "dracaufeu") {
        attacks = { "Flammeche", "Lance-Flamme", "Danse Flamme", "Seisme" };
    } else if (playerPokemonName == "florizarre") {
        attacks = { "Tranch Herbe", "Fouet Lianes", "Tempete Verte", "Poudre Dodo" };
    } else if (playerPokemonName == "tortank") {
        attacks = { "Pistolet a O", "Hydrocanon", "Surf", "Coud Krane" };
    } else if (playerPokemonName == "alakazam") {
        attacks = { "Choc Mental", "Psyko", "Ball'Ombre", "Plénitude" };
    } else if (playerPokemonName == "ronflex") {
        attacks = { "Écrasement", "Repos", "Ronflement", "Giga Impact" };
    } else {
        attacks = { "Attaque 1", "Attaque 2", "Attaque 3", "Attaque 4" };
    }

    for (size_t i = 0; i < attacks.size(); ++i) {
        sf::Text option(attacks[i], font, 24);
        option.setPosition(450, 450 + i * 30);
        option.setFillColor(i == 0 ? sf::Color::Yellow : sf::Color::White);
        attackOptions.push_back(option);
    }

    battleText.setString("Un combat sauvage commence !");
    currentState = GameState::BATTLE_MENU;
}
