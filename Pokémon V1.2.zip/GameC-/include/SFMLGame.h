#ifndef SFMLGAME_H
#define SFMLGAME_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <map>
#include <vector>
#include <string>
#include "Game.h"

class SFMLGame {
public:
    SFMLGame();
    void run();

private:
    enum class GameState {
        MAIN_MENU,
        POKEMON_SELECT,
        BATTLE,
        BATTLE_MENU,
        ATTACK_ANIMATION,
        BATTLE_RESULT
    };

    void loadResources();
    void handleEvents();
    void update(float deltaTime);
    void render();
    void handleMainMenu();
    void handlePokemonSelect();
    void handleBattleMenu();
    void handleAttackAnimation(float deltaTime);
    void startBattle();
    void selectOption(int index);

    sf::RenderWindow window;
    sf::Event event;

    GameState currentState;
    Game gameLogic;

    sf::Font font;
    sf::Music music;

    sf::RectangleShape menuBackground;
    sf::RectangleShape selectBackground;
    sf::Text battleText;
    sf::Text resultText;

    std::vector<sf::Text> menuOptions;
    std::vector<sf::Text> pokemonOptions;
    std::vector<sf::Text> attackOptions;

    std::map<std::string, sf::Texture> textures;
    std::map<std::string, sf::SoundBuffer> soundBuffers;
    std::map<std::string, sf::Sound> sounds;

    sf::Sprite playerPokemonSprite;
    sf::Sprite opponentPokemonSprite;

    sf::RectangleShape playerHealthBarBackground;
    sf::RectangleShape opponentHealthBarBackground;
    sf::RectangleShape playerHealthBar;
    sf::RectangleShape opponentHealthBar;

    float animationTimer;
    bool animationPlaying;

    int selectedAttack;
    int selectedPokemonIndex;

    float backgroundOffset;
};

#endif // SFMLGAME_H