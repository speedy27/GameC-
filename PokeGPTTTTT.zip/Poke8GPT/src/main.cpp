#include "SFMLGame.h"

int main() {
    // Crée et lance l'interface graphique
    SFMLGame game;
    game.runGame();

    return 0;
}
